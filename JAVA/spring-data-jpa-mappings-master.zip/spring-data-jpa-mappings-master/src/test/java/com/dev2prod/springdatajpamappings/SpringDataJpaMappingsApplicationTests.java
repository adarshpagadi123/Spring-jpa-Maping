package com.dev2prod.springdatajpamappings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaMappingsApplicationTests {

    @Test
    void contextLoads() {
    }

}
